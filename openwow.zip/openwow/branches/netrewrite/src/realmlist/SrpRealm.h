//////////////////////////////////////////////////////////////////////
//  SrpRealm 
//  
//  SrpRealm headers
//////////////////////////////////////////////////////////////////////

// copyright (c) 2005 team wsd
//
// this program is free software; you can redistribute it and/or modify
// it under the terms of the gnu general public license as published by
// the free software foundation; either version 2 of the license, or
// (at your option) any later version.
//
// this program is distributed in the hope that it will be useful,
// but without any warranty; without even the implied warranty of
// merchantability or fitness for a particular purpose.  see the
// gnu general public license for more details.
//
// you should have received a copy of the gnu general public license
// along with this program; if not, write to the free software
// foundation, inc., 59 temple place - suite 330, boston, ma 02111-1307, usa.

#ifndef SRPREALM_H
#define SRPREALM_H

#include "Common.h"
#include "bigint.h"

// Uncomment this to get debug output of intermediate SRP auth results
//#define SRP_DEBUG

class SrpRealm
{
protected:
	char *UserName;
	uint8 b [32];
	uint8 v [32];
	uint8 BR [32];
	uint8 N [32];
	uint8 M1 [20];
	uint8 M2 [20];
	uint8 SS_Hash [40];
	uint8 salt [32];
public:
	SrpRealm ();
	~SrpRealm ();

	void Challenge (const char *userName, char *passwd);
	void Proof (uint8 *A);
};

/**
 * Convert a hexadecimal string to a binary array.
 * @arg dst
 *   Destination array
 * @arg src
 *   Source string (e.g. "12345678abcdef0")
 * @arg size
 *   Destination array size in bytes
 */
void Hex2Bin (uint8 *dst, size_t size, char *src);

/**
 * Convert a binary array to a hexadecimal string.
 * @arg dst
 *   Destination string
 * @arg src
 *   Source binary array
 * @arg size
 *   Source binary array length in bytes
 */
void Bin2Hex (char *dst, uint8 *src, size_t size);

#endif
