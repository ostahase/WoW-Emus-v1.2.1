/*
    Realm client
    Copyright (C) 2005 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __REALMCLIENT_H__
#define __REALMCLIENT_H__

#include "Client.h"
#include "SrpRealm.h"
#include "StringFun.h"
#include "RealmProto.h"

class RealmListSrv;

/**
 * This is the realm network client.
 */
class RealmClient : public Client, public SrpRealm
{
protected:
	/// A pointer to parent realm server
	RealmListSrv *Server;

	/// Send the packet and free it
	void Send (NetworkPacket *outpkt)
	{ socket->SendData (outpkt); outpkt->DecRef (); }

	void FailLogin (RealmErrors err, const char *errstr);

	void HandleLogonChallenge (CMSG_LOGON_CHALLENGE_t &inpkt);
	void HandleReconnectChallenge (CMSG_RECONNECT_CHALLENGE_t &inpkt)
	{ HandleLogonChallenge (*(CMSG_LOGON_CHALLENGE_t *)&inpkt); }
	void HandleLogonProof (CMSG_LOGON_PROOF_t &inpkt);
	void HandleRealmList (CMSG_REALMLIST_t &inpkt);

public:
	/**
	 * Initialize the realm network client.
	 */
	RealmClient (Socket *sock, RealmListSrv *serv);

	/**
	 * Called when any event (one of those requested by socket->InterestedEvents())
	 * happens with the socket.
	 * @arg mask
	 *   Event mask (a combination of PF_XXX flags)
	 */
	virtual void SocketEvent (uint mask);
};

#endif // __REALMCLIENT_H__
