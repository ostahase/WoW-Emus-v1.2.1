/*
** Lua binding: worldsrv
** Generated automatically by tolua++-1.0.5 on Sat May  7 03:50:05 2005.
*/
extern "C" {
#include "lua.h"
}
/* Exported function */
extern int tolua_worldsrv_open (lua_State* tolua_S);

