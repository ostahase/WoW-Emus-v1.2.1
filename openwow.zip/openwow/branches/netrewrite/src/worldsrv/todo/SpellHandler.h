/*
    Spell Handler
    Receives all messages with spell management opcodes
    Copyright (C) 2004 Team Python
    Copyright (C) 2005 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __SPELLHANDLER_H__
#define __SPELLHANDLER_H__

#include "MsgHandler.h"

#include "Spell.h"
#include "UpdateFields.h"
#include <iostream> 
#include <cstdlib> 


class Unit;
class GameClient;
class DatabaseInterface;

class SpellHandler : public MsgHandler
{
public:
	SpellHandler();
	~SpellHandler();
	void HandleMsg( NetworkPacket & recv_data, GameClient *pClient );
	int applySpell( GameClient *pClient, Unit* target, uint32 spell, SpellEntry spellEntry);
	int usePotion(GameClient *pClient, uint32 spell, SpellEntry spellEntry, uint32 targets);
	int setAura(Unit *pUnit, uint32 spell);
	float CalcDistance(float sx, float sy, float sz, float dx, float dy, float dz);

	guid PetCreature (GameClient *pClient, char* pName); 
    
	float lrand, rrand; 
	float abstand, winkel; 
	float CalcDistance2d( float xe, float ye, float xz, float yz ); 
	bool inbogen( float radius,  float xM, float yM,float zM, float offnung, float drehung, float xP, float yP,float zP ); 
	float geteinfachererwinkel( float winkel ); 
	float getwinkel( float xe, float ye, float xz, float yz ); 


protected:

};

#endif // __SPELLHANDLER_H__
