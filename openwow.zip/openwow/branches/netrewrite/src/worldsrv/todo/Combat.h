/*
    Combat
    Provides basic Combat functions
    Copyright (C) 2004 Team Python
    Copyright (C) 2005 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __COMBATHANDLER_H__
#define __COMBATHANDLER_H__

#include "MsgHandler.h"
#include "Object.h"

class Unit;
class GameClient;
class NetworkPacket;
struct UpdateMask;
class CombatHandler
{
public:
	CombatHandler() {};
	virtual ~CombatHandler() {};

	void HandleMsg (NetworkPacket & recv_data, GameClient *pClient);

	/////////////////////////////////////////////////////////////////////////
	//  Deals damage from pAttacker to pVictim
	//  Does checks for death and lots of other keen things
	void DealDamage (Unit *pAttacker, Unit *pVictim, uint32 damage);

	void smsg_AttackStart (Unit* pAttacker, Unit* pVictim);
	void smsg_AttackStop (Unit* pAttacker, guid victim_guid);

	void AttackerStateUpdate (Unit *pAttacker, Unit *pVictim, uint32 damage);
	void Heal (Unit *pAttacker, Unit *pVictim, uint32 damage);

	uint32 petGUID;

};

#endif // __COMBATHANDLER_H__
