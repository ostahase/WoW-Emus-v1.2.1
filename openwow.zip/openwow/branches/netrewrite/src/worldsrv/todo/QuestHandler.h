/*
    Quest Handler
    Handles quest related opcodes
    Copyright (C) 2004 Team Python
    Copyright (C) 2005 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __QUESTHANDLER_H__
#define __QUESTHANDLER_H__

#include "MsgHandler.h"

class Quest;
class QuestHandler : public MsgHandler
{
public:
	QuestHandler();
	~QuestHandler();

	void HandleMsg( NetworkPacket & recv_data, GameClient *pClient );
	void addQuest(Quest *pQuest);
	Quest* getQuest(uint32 quest_id);
	void SetNpcFlagsForTalkToQuest(GameClient* pClient, uint32 guid1, uint32 targetGuid);
protected:
	// Quest data 
	typedef std::map<uint32, Quest*> QuestMap;
	QuestMap mQuests;
};

#endif // __QUESTHANDLER_H__
