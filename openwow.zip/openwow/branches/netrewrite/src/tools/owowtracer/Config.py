import ConfigParser
import os.path

config = None
servers = []

class Server:
    def __init__(self, host=None, user= None, password=None, connection_type=None, description=None):
        self.host = host
        self.description = description
        self.user = user
        self.password = password
        self.connection_type = connection_type
        self.id = 0
    
    def save(self):
        if config is None:
            return False
        if not self.id:
            i = 0
            while(config.has_section("server_%i" %i)): 
                i += 1
            self.id = i
            
        sec = "server_%i" %self.id
        if not config.has_section(sec):
            config.add_section(sec)
        config.set(sec,"host", self.host)
        config.set(sec,"description", self.description)
        config.set(sec,"user", self.user)
        config.set(sec,"password", self.password)
        config.set(sec,"connection_type", self.connection_type)
        if self not in servers:
            servers.append(self)

def save(evt = None):
    fp = file(os.path.expanduser('~/.owowtracerrc'),"w")
    config.write(fp)
    fp.close()
    print "Config saved"

def load():
    global config
    config = ConfigParser.SafeConfigParser()
    config.read(['owowtracerrc', os.path.expanduser('~/.owowtracerrc')])
    load_servers()
    print "Config loaded", config
    
def load_servers():
    global servers
    if servers is None or config is None:
        return
    servers = []
    for section in config.sections():
        if section[0:7] == "server_":
            s = Server()
            for (key,value) in config.items(section):
                if s.__dict__.has_key(key):
                    s.__dict__[key] = value
            try: s.id = int(section[7:])
            except: pass
            servers.append(s)
            
if config is None:
    load()
    import atexit
    atexit.register(save)
    

