class Connection:
    title = _("Emulated Connection")
    def __init__(self):
        pass
