import asyncore
import socket
from __init__ import *

TS_TRAFFIC = 0x01
TR_INJECT = 0x02
TR_UPDATE_REQUEST = 0x03
TS_UPDATE_CLIENT = 0x04
TR_TRACE = 0x05
  
class Connection(asyncore.dispatcher):
	title = "OpenWoW tracer port"
	def __init__(self, host="", user="", password=""):
		print host
		if host.find(":") != -1:
			self.port = int(host[host.rfind(":")+1:])
			self.host = host[:host.rfind(":")]
		else:
			self.port = 6342
			self.host = host
		asyncore.dispatcher.__init__(self)
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.outbuffer = ''
		self.inbuffer = ''
		self.handler = {}
	
	def register(self,evt, func):
		if not self.handler.has_key(evt):
			self.handler[evt] = []
		self.handler[evt].append(func)
	
	def unregister(self, evt, func):
		if self.handler.has_key(evt):
			self.handler[evt].remove(func)

	def emit(self, evt, args):
		for i in self.handler[evt]:
			if iscallable(i):
				i(args)
		
	
	def connect(self):
		asyncore.dispatcher.connect(self, (self.host, self.port) )
	
	def handle_connect(self):
		pass
		
	def handle_read(self):
		self.inbuffer += self.recv(8192)
		while self.inbuffer:
			(length, opcode) = struct.unpack("IB",self.inbuffer)
			if len(self.inbuffer) < length:
				break; # no more packets to process
			self.inbuffer[struct.calcsize("IB"):]
			if opcode == TS_TRAFFIC:
				(account, direction, length) = struct.unpack("IBH",self.inbuffer)
				data = self.inbuffer[stuct.calcsize("IBH")+1:stuct.calcsize["IBH"]+1+length]
				print "TRAFFIC:"
				print account, direction, length
				print data
				self.emit(TRAFFIC, TraficPacket(account, direction, length,data))
			elif opcode == TS_UPDATE_CLIENT:
				account = struct.unpack("I",self.inbuffer)
				name = ""
				pos = struct.calcsize("I")
				while self.inbuffer[pos]:
					name += struct.unpack("c",self.inbuffer[pos])
					pos += 1
				self.emit(UPDATE_CLIENT, UpdatePacket(account, name))
			else:
				print "Unknown op packet"
			
			
		
	def writable(self):
		return (len(self.outbuffer) > 0)

	def handle_write(self):
		sent = self.send(self.outbuffer)
		self.outbuffer = self.outbuffer[sent:]

CONNECTION_TYPES[0] = owowtracer.Connection
