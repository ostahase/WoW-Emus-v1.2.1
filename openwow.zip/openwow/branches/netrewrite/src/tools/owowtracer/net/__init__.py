import owowtracer
#import debug

TRAFFIC = 1
UPDATE_CLIENT = 2


CONNECTION_TYPES = {
    #1:debug.Connection
}

class TraficPacket:
	def __init__(self, account, direction, length, data):
		self.account = account
		self.direction = direction
		self.length = length
		self.data = data

class UpdatePacket:
	def __init__(self, account, name):
		self.account = account
		self.name = name

class UpdateRequest:
	def __init__(self, account = 0):
		self.account = account
