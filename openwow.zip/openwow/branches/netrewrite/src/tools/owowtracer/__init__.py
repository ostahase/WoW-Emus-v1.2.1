import Manager

MANAGER = Manager.Manager()
