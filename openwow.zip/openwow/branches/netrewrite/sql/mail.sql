-- MySQL dump 8.23
--
-- Host: localhost    Database: wow
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `mail`
--

DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `mailId` int(10) unsigned NOT NULL default '0',
  `sender` int(10) unsigned NOT NULL default '0',
  `recipient` int(10) unsigned NOT NULL default '0',
  `subject` tinytext,
  `body` mediumtext,
  `item` int(10) unsigned NOT NULL default '0',
  `time` int(10) unsigned NOT NULL default '0',
  `money` int(10) unsigned NOT NULL default '0',
  `COD` int(10) unsigned NOT NULL default '0',
  `checked` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`mailId`)
) TYPE=MyISAM;

