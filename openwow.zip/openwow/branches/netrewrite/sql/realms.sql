-- MySQL dump 8.23
--
-- Host: localhost    Database: wow_rs
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `realms`
--

DROP TABLE IF EXISTS `realms`;
CREATE TABLE `realms` (
  `name` varchar(32) NOT NULL default '',
  `address` varchar(32) NOT NULL default '',
  `population` float(5,3) unsigned NOT NULL default '0.000',
  `color` tinyint(3) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  `online` tinyint(1) NOT NULL default '0',
  `language` tinyint(3) NOT NULL default '0',
  `players` tinyint(5) NOT NULL default '0',
  `gms` tinyint(5) NOT NULL default '0',
  PRIMARY KEY  (`name`)
) TYPE=MyISAM;

--
-- Dumping data for table `realms`
--


INSERT INTO `realms` VALUES ('Asteroth','192.168.0.1:8129',0.000,0,0,0,1,0,0);
INSERT INTO `realms` VALUES ('Azaroth','192.168.0.2:8129',0.500,0,1,1,1,0,0);
INSERT INTO `realms` VALUES ('Behemoth','192.168.0.3:8129',0.555,1,6,1,1,0,0);
INSERT INTO `realms` VALUES ('zap','217.170.93.196:8129',0.000,0,0,1,1,1,0);

