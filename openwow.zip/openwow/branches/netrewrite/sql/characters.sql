-- MySQL dump 8.23
--
-- Host: localhost    Database: wow
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
CREATE TABLE `characters` (
  `guid` int(10) unsigned NOT NULL default '0',
  `login` varchar(32) NOT NULL default '',
  `data` mediumtext NOT NULL,
  `name` varchar(24) NOT NULL default '',
  `positionX` float NOT NULL default '0',
  `positionY` float NOT NULL default '0',
  `positionZ` float NOT NULL default '0',
  `orientation` float NOT NULL default '0',
  `mapId` int(10) unsigned NOT NULL default '0',
  `zoneId` int(10) unsigned NOT NULL default '0',
  `taxiMask` varchar(43) NOT NULL default '',
  `tutorialMask` varchar(43) NOT NULL default '',
  `actions` mediumtext NOT NULL,
  `data0` mediumtext NOT NULL,
  `data1` mediumtext NOT NULL,
  PRIMARY KEY  (`guid`),
  UNIQUE KEY `idxname` (`name`)
) TYPE=MyISAM;

