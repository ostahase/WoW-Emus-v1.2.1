-- MySQL dump 8.23
--
-- Host: localhost    Database: wow
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `protochar`
--

DROP TABLE IF EXISTS `protochar`;
CREATE TABLE `protochar` (
  `race` tinyint(3) unsigned NOT NULL default '0',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `mapID` mediumint(8) unsigned NOT NULL default '0',
  `zoneID` mediumint(8) unsigned NOT NULL default '0',
  `positionX` float NOT NULL default '0',
  `positionY` float NOT NULL default '0',
  `positionZ` float NOT NULL default '0',
  `displayID` smallint(5) unsigned NOT NULL default '0',
  `BaseStrength` tinyint(3) unsigned NOT NULL default '0',
  `BaseAgility` tinyint(3) unsigned NOT NULL default '0',
  `BaseStamina` tinyint(3) unsigned NOT NULL default '0',
  `BaseIntellect` tinyint(3) unsigned NOT NULL default '0',
  `BaseSpirit` tinyint(3) unsigned NOT NULL default '0',
  `BaseHealth` mediumint(8) unsigned NOT NULL default '0',
  `BaseMana` mediumint(8) unsigned NOT NULL default '0',
  `BaseRage` mediumint(8) unsigned NOT NULL default '0',
  `BaseFocus` mediumint(8) unsigned NOT NULL default '0',
  `BaseEnergy` mediumint(8) unsigned NOT NULL default '0',
  `attackpower` mediumint(8) unsigned NOT NULL default '0',
  `mindmg` float NOT NULL default '0',
  `maxdmg` float NOT NULL default '0',
  `item1` mediumint(8) unsigned NOT NULL default '0',
  `item1_slot` tinyint(3) unsigned NOT NULL default '0',
  `item2` mediumint(8) unsigned NOT NULL default '0',
  `item2_slot` tinyint(3) unsigned NOT NULL default '0',
  `item3` mediumint(8) unsigned NOT NULL default '0',
  `item3_slot` tinyint(3) unsigned NOT NULL default '0',
  `item4` mediumint(8) unsigned NOT NULL default '0',
  `item4_slot` tinyint(3) unsigned NOT NULL default '0',
  `item5` mediumint(8) unsigned NOT NULL default '0',
  `item5_slot` tinyint(3) unsigned NOT NULL default '0',
  `item6` mediumint(8) unsigned NOT NULL default '0',
  `item6_slot` tinyint(3) unsigned NOT NULL default '0',
  `item7` mediumint(8) unsigned NOT NULL default '0',
  `item7_slot` tinyint(3) unsigned NOT NULL default '0',
  `item8` mediumint(8) unsigned NOT NULL default '0',
  `item8_slot` tinyint(3) unsigned NOT NULL default '0',
  `item9` mediumint(8) unsigned NOT NULL default '0',
  `item9_slot` tinyint(3) unsigned NOT NULL default '0',
  `item10` mediumint(8) unsigned NOT NULL default '0',
  `item10_slot` tinyint(3) unsigned NOT NULL default '0',
  `spell1` smallint(5) unsigned NOT NULL default '0',
  `spell2` smallint(5) unsigned NOT NULL default '0',
  `spell3` smallint(5) unsigned NOT NULL default '0',
  `spell4` smallint(5) unsigned NOT NULL default '0',
  `spell5` smallint(5) unsigned NOT NULL default '0',
  `spell6` smallint(5) unsigned NOT NULL default '0',
  `spell7` smallint(5) unsigned NOT NULL default '0',
  `spell8` smallint(5) unsigned NOT NULL default '0',
  `spell9` smallint(5) unsigned NOT NULL default '0',
  `spell10` smallint(5) unsigned NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table `protochar`
--


INSERT INTO `protochar` VALUES (1,1,0,12,-8949.95,-132.493,83.5312,49,23,20,22,20,20,60,0,1000,0,0,29,5,6,38,3,39,6,40,7,2362,16,25,15,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (2,1,1,14,-618.518,-4251.67,38.718,51,26,17,24,17,23,80,0,1000,0,0,35,6,6,6125,3,139,6,140,7,12282,15,0,0,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (3,1,0,1,-6240.32,331.033,382.758,53,25,16,25,19,19,90,0,1000,0,0,33,5,6,38,3,39,6,40,7,12282,15,0,0,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (4,1,1,141,10311.3,832.463,1326.41,55,20,25,21,20,20,50,0,1000,0,0,21,4,4,6120,3,6121,6,6122,7,2362,16,25,15,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (5,1,0,85,1676.35,1677.45,121.67,57,22,18,23,18,25,70,0,1000,0,0,27,4,5,6125,3,139,6,140,7,2362,16,25,15,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (6,1,1,215,-2917.58,-257.98,52.9968,59,28,15,24,15,22,80,0,1000,0,0,39,6,7,6125,3,139,6,2361,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (7,1,0,1,-6240.32,331.033,382.758,1563,18,23,21,23,20,50,0,1000,0,0,10,3,4,38,3,39,6,40,7,2362,16,25,15,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (8,1,1,14,-618.518,-4251.67,38.718,1478,24,22,23,16,21,70,0,1000,0,0,29,5,7,6125,3,139,6,2362,16,25,15,0,0,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (1,2,0,12,-8949.95,-132.493,83.5312,49,22,20,22,20,21,58,80,0,0,0,27,4,5,45,3,44,6,43,7,2361,15,0,0,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (3,2,0,1,-6240.32,331.033,382.758,53,24,16,25,19,20,88,79,0,0,0,31,5,6,45,3,44,6,43,7,2361,15,0,0,0,0,0,0,0,0,0,0,0,0,6603,107,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (4,3,1,141,10311.3,832.463,1326.41,55,17,28,20,20,21,46,85,0,0,0,26,4,5,148,3,147,6,129,7,37,15,2504,17,0,0,0,0,0,0,0,0,0,0,6603,2764,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (2,3,1,14,-618.518,-4251.67,38.718,51,23,20,23,17,24,76,82,0,0,0,25,4,5,127,3,6126,6,6127,7,37,15,2504,17,0,0,0,0,0,0,0,0,0,0,6603,2764,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (3,3,0,1,-6240.32,331.033,382.758,53,22,19,24,19,20,86,84,0,0,0,24,4,5,148,3,147,6,129,7,37,15,2508,17,0,0,0,0,0,0,0,0,0,0,6603,2764,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (6,3,1,215,-2917.58,-257.98,52.9968,59,25,18,23,15,23,76,80,0,0,0,16,5,7,127,3,6126,6,37,15,2508,17,0,0,0,0,0,0,0,0,0,0,0,0,6603,2764,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (8,3,1,14,-618.518,-4251.67,38.718,1478,21,25,22,16,22,66,81,0,0,0,16,5,7,127,3,6126,6,37,15,2504,17,0,0,0,0,0,0,0,0,0,0,0,0,6603,2764,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (1,4,0,12,-8949.95,-132.493,83.5312,49,21,23,21,20,20,55,0,0,0,100,27,10,13,49,3,48,6,47,7,2092,15,2947,17,0,0,0,0,0,0,0,0,0,0,6603,2764,81,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (2,4,1,14,-618.518,-4251.67,38.718,51,24,20,23,17,23,75,0,0,0,100,30,4,4,2105,3,120,6,121,7,2092,15,3111,17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (3,4,0,1,-6240.32,331.033,382.758,53,23,19,24,19,19,85,0,0,0,100,30,4,4,49,3,48,6,47,7,2092,15,2947,17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (4,4,1,141,10311.3,832.463,1326.41,55,18,28,20,20,20,45,0,0,0,100,30,4,4,49,3,48,6,47,7,2092,15,2947,17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (5,4,0,85,1676.35,1677.45,121.67,57,20,21,22,18,25,65,0,0,0,100,30,4,4,2105,3,120,6,121,7,2092,15,2947,17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (7,4,0,1,-6340.32,331.033,382.758,1563,16,26,20,23,20,45,0,0,0,100,30,4,4,49,3,48,6,47,7,2092,15,2947,17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (8,4,1,14,-618.518,-4251.67,38.718,1478,22,25,22,16,21,65,0,0,0,100,30,4,4,2105,3,120,6,121,7,2092,15,3111,17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (1,5,0,12,-8949.95,-132.493,83.5312,49,20,20,20,22,23,52,160,0,0,0,30,4,4,53,3,6098,4,52,6,51,7,36,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (3,5,0,1,-6240.32,331.033,382.758,53,22,16,23,21,22,82,145,0,0,0,30,4,4,53,3,6098,4,52,6,51,7,36,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (4,5,1,141,10311.3,832.463,1326.41,55,17,25,19,22,23,51,160,0,0,0,30,4,4,53,3,6119,4,52,6,51,7,36,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (5,5,0,85,1676.35,1677.45,121.67,57,19,18,21,20,28,62,130,0,0,0,30,4,4,53,3,6144,4,52,6,51,7,36,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (8,5,1,14,-618.518,-4251.67,38.718,1478,21,22,21,18,24,62,128,0,0,0,30,4,4,53,3,6144,4,52,6,36,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (2,7,1,14,-618.518,-4251.67,38.718,51,24,17,23,18,25,77,73,0,0,0,30,4,4,154,3,153,6,36,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (6,7,1,215,-2917.58,-257.98,52.9968,59,26,15,23,16,24,77,71,0,0,0,30,4,4,154,3,153,6,36,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (8,7,1,14,-618.518,-4251.67,38.718,1478,22,22,22,17,23,67,72,0,0,0,30,4,4,6134,3,153,6,36,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (1,8,0,12,-8949.95,-132.493,83.5312,49,20,20,20,23,22,52,165,0,0,0,30,4,4,6096,3,56,4,1395,6,55,7,35,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (5,8,0,85,1676.35,1677.45,121.67,57,19,18,21,21,27,62,135,0,0,0,30,4,4,6096,3,6140,4,1395,6,55,7,35,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (7,8,0,1,-6340.32,331.033,382.758,1563,15,23,19,26,22,51,210,0,0,0,30,4,4,6096,3,56,4,1395,6,55,7,35,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (8,8,1,14,-618.518,-4251.67,38.718,1478,21,22,21,19,23,62,119,0,0,0,30,4,4,6096,3,6140,4,1395,6,55,7,35,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (1,9,0,12,-8949.95,-132.493,83.5312,49,20,20,21,22,22,53,140,0,0,0,30,4,4,6097,3,57,4,1396,6,59,7,2092,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (2,9,1,14,-618.518,-4251.67,38.718,51,23,17,23,19,25,73,109,0,0,0,30,4,4,6129,4,1396,6,59,7,2092,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (5,9,0,85,1676.35,1677.45,121.67,57,19,18,22,20,27,63,110,0,0,0,30,4,4,6129,4,1396,6,59,7,2092,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (7,9,0,1,-6340.32,331.033,382.758,1563,15,23,20,25,22,43,185,0,0,0,30,4,4,6097,3,57,4,1396,6,59,7,2092,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (4,11,1,141,10311.3,832.463,1326.41,55,18,25,19,22,22,53,100,0,0,0,30,4,4,6123,4,6124,6,3661,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
INSERT INTO `protochar` VALUES (6,11,1,215,-2917.58,-257.98,52.9968,59,26,15,22,17,24,74,67,0,0,0,30,4,4,6139,4,6124,6,35,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

