-- MySQL dump 8.23
--
-- Host: localhost    Database: wow_rs
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `login` varchar(32) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `level` tinyint(1) NOT NULL default '0',
  `authip` varchar(20) NOT NULL default '0.0.0.0',
  `sessionkey` varchar(80) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `joindate` timestamp(14) NOT NULL,
  `lastlogin` timestamp(14) NOT NULL,
  `banned` tinyint(1) unsigned NOT NULL default '0',
  `data0` mediumtext NOT NULL,
  `data1` mediumtext NOT NULL,
  `data2` mediumtext NOT NULL,
  PRIMARY KEY  (`login`)
) TYPE=MyISAM;

--
-- Dumping data for table `accounts`
--


INSERT INTO `accounts` VALUES ('DEVEL','test',4,'','','',00000000000000,00000000000000,0,'','','');
INSERT INTO `accounts` VALUES ('GM','test',3,'','','',00000000000000,00000000000000,0,'','','');
INSERT INTO `accounts` VALUES ('SEER','test',2,'','','',00000000000000,00000000000000,0,'','','');
INSERT INTO `accounts` VALUES ('COUNCELOR','test',1,'','','',00000000000000,00000000000000,0,'','','');
INSERT INTO `accounts` VALUES ('PLAYER','test',0,'','','',00000000000000,00000000000000,0,'','','');

