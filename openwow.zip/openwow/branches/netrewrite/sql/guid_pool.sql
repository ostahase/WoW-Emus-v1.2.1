-- MySQL dump 8.23
--
-- Host: localhost    Database: wow
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `guid_pool`
--

DROP TABLE IF EXISTS `guid_pool`;
CREATE TABLE `guid_pool` (
  `guid_high` int(10) unsigned NOT NULL default '0',
  `guid_low` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid_high`)
) TYPE=MyISAM;

